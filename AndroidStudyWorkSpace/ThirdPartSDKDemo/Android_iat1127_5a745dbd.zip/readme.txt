1.使用带UI接口时，请将assets下文件拷贝到项目中；
2.文档说明请参考:http://doc.xfyun.cn/msc_android/；
3.demo 使用时，已import module 形式导入到自己的工程。
